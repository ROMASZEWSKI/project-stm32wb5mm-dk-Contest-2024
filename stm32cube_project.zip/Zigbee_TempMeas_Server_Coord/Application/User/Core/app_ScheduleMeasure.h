/*
 * app_ScheduleMeasure.h
 *
 *  Created on: Jan 24, 2024
 *      Author: mag
 */

#ifndef APPLICATION_USER_CORE_APP_SCHEDULEMEASURE_H_
#define APPLICATION_USER_CORE_APP_SCHEDULEMEASURE_H_

void Schedule_Start_Measure(void);
void Schedule_Stop_Measure(void);
void init_ScheduleMeasure(void);
void Selection(void);
void Measuring(void);

#endif /* APPLICATION_USER_CORE_APP_SCHEDULEMEASURE_H_ */
