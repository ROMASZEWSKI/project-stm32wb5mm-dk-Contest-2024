/*
 * button.c
 *
 *  Created on: Oct 10, 2024
 *      Author: mag
 */

#include "button.h"

static GPIO_TypeDef* BUTTON_PORT[BUTTONn] = {BUTTON_USER1_GPIO_PORT, BUTTON_USER2_GPIO_PORT};
static const uint16_t BUTTON_PIN[BUTTONn] = {BUTTON_USER1_PIN, BUTTON_USER2_PIN};
static const IRQn_Type BUTTON_IRQn[BUTTONn] = {BUTTON_USER1_EXTI_IRQn, BUTTON_USER2_EXTI_IRQn};



/**
  * @brief  Configure Button GPIO and EXTI Line.
  * @param  Button Specifies the Button to be configured.
  *   This parameter should be:
  *     @arg BUTTON_USER1
  *     @arg BUTTON_USER2
  * @param  ButtonMode Specifies Button mode.
  *   This parameter can be one of following parameters:
  *     @arg BUTTON_MODE_GPIO: Button will be used as simple IO
  *     @arg BUTTON_MODE_EXTI: Button will be connected to EXTI line with interrupt
  *                            generation capability
  * @retval BSP error code
  */
int32_t BSP_PB_Init(Button_TypeDef Button, ButtonMode_TypeDef ButtonMode)
{
  GPIO_InitTypeDef gpio_init_structure = {0};
  //static BSP_EXTI_LineCallback button_callback[BUTTONn] = {BUTTON_USER1_EXTI_Callback, BUTTON_USER2_EXTI_Callback};
  static uint32_t button_interrupt_priority[BUTTONn] = {BSP_BUTTON_USERx_IT_PRIORITY, BSP_BUTTON_USERx_IT_PRIORITY};
  //static const uint32_t button_exti_line[BUTTONn] = {BUTTON_USER1_EXTI_LINE, BUTTON_USER2_EXTI_LINE};

  /* Enable the BUTTON Clock */
  BUTTON_USERx_GPIO_CLK_ENABLE(Button);

  gpio_init_structure.Pin = BUTTON_PIN[Button];
  gpio_init_structure.Pull = GPIO_PULLUP;
  gpio_init_structure.Speed = GPIO_SPEED_FREQ_HIGH;

  if (ButtonMode == BUTTON_MODE_GPIO)
  {
    /* Configure Button pin as input */
    gpio_init_structure.Mode = GPIO_MODE_INPUT;
    HAL_GPIO_Init(BUTTON_PORT[Button], &gpio_init_structure);
  }
  else /* (ButtonMode == BUTTON_MODE_EXTI) */
  {
    /* Configure Button pin as input with External interrupt */
    gpio_init_structure.Mode = GPIO_MODE_IT_FALLING;

    HAL_GPIO_Init(BUTTON_PORT[Button], &gpio_init_structure);

    //(void)HAL_EXTI_GetHandle(&hpb_exti[Button], button_exti_line[Button]);
    //(void)HAL_EXTI_RegisterCallback(&hpb_exti[Button], HAL_EXTI_COMMON_CB_ID, button_callback[Button]);

    /* Enable and set Button EXTI Interrupt to the lowest priority */
    HAL_NVIC_SetPriority((BUTTON_IRQn[Button]), button_interrupt_priority[Button], 0x00);
    HAL_NVIC_EnableIRQ((BUTTON_IRQn[Button]));
  }

  return BSP_ERROR_NONE;
}

/**
  * @brief  DeInitialize Push Button.
  * @param  Button  Button to be configured
  *   This parameter should be:
  *     @arg BUTTON_USER1
  *     @arg BUTTON_USER2
  * @note BSP_PB_DeInit() does not disable the GPIO clock
  * @retval BSP error code
  */
int32_t BSP_PB_DeInit(Button_TypeDef Button)
{
  HAL_NVIC_DisableIRQ((BUTTON_IRQn[Button]));
  HAL_GPIO_DeInit(BUTTON_PORT[Button], BUTTON_PIN[Button]);

  return BSP_ERROR_NONE;
}

/**
  * @brief  Return the selected Button state.
  * @param  Button  Specifies the Button to be checked.
  *   This parameter should be:
  *     @arg BUTTON_USER1
  *     @arg BUTTON_USER2
  * @retval 0 means released, 1 means pressed.
  */
int32_t BSP_PB_GetState(Button_TypeDef Button)
{
  return (int32_t)HAL_GPIO_ReadPin(BUTTON_PORT[Button], BUTTON_PIN[Button]);
}

/**
  * @brief  BSP Push Button callback
  * @param  Button: Specifies the Button to be checked.
  *         This parameter can be one of following parameters:
  *           @arg BUTTON_SW1
  *           @arg BUTTON_SW2
  * @retval None.
  */
__weak void BSP_PB_Callback(Button_TypeDef Button)
{
  /* Prevent unused argument(s) compilation warning */
  UNUSED(Button);

  /* This function should be implemented by the user application.
     It is called into this driver when an event on Button is triggered. */
}

/**
  * @brief  BSP PB interrupt handler.
  * @param  Button Button where interrupt occurs.
  *   This parameter should be:
  *     @arg BUTTON_USER1
  * @retval None.
  */
void BSP_PB_IRQHandler(Button_TypeDef Button)
{
  HAL_EXTI_IRQHandler(&hpb_exti[Button]);
}


