/*
 * pwmled.c
 *
 *  Created on: Oct 10, 2024
 *      Author: mag
 */
#include "pwmled.h"

static TIM_HandleTypeDef PwmLed_TimerHandle = {0};

static __IO uint32_t CycleCount = 0;

static aPwmLedGsData_TypeDef PWM_LED_GSDATA = {0};

static void    PWM_LED_SendBit(uint8_t bit);
static void    PWM_LED_SenByte(uint8_t byte);
static void    PWM_LED_Wait(uint32_t NbCycles);

static void TIM17_MspInit(TIM_HandleTypeDef *htim);
static void TIM17_MspDeInit(TIM_HandleTypeDef *htim);
static int32_t PWM_LED_WriteData(aPwmLedGsData_TypeDef aPwmLedGsData);
/**
  * @brief  Configure PWM LED Driver.
  * @retval BSP error code
  */
int32_t PWM_LED_Init(void)
{
  int32_t ret = BSP_ERROR_NONE;

  GPIO_InitTypeDef  gpio_config = {0};

  //PWM_LED_SDI_GPIO_CLK_ENABLE();
  //gpio_config.Pin       = PWM_LED_SDI_GPIO_PIN;
  //gpio_config.Mode      = GPIO_MODE_OUTPUT_PP;
  //gpio_config.Pull      = GPIO_PULLDOWN;
  //HAL_GPIO_Init(PWM_LED_SDI_GPIO_PORT, &gpio_config);
  //HAL_GPIO_WritePin(PWM_LED_SDI_GPIO_PORT, PWM_LED_SDI_GPIO_PIN, GPIO_PIN_RESET);

  PWM_LED_SELECT_GPIO_CLK_ENABLE();
  gpio_config.Pin       = PWM_LED_SELECT_GPIO_PIN;
  gpio_config.Mode      = GPIO_MODE_OUTPUT_PP;
  gpio_config.Pull      = GPIO_PULLDOWN;
  HAL_GPIO_Init(PWM_LED_SELECT_GPIO_PORT, &gpio_config);
  HAL_GPIO_WritePin(PWM_LED_SELECT_GPIO_PORT, PWM_LED_SELECT_GPIO_PIN, GPIO_PIN_RESET);

  PwmLed_TimerHandle.Instance = PWM_LED_TIM;
  /* TIM17 MSP initialization */
  TIM17_MspInit(&PwmLed_TimerHandle);

  PwmLed_TimerHandle.Init.Prescaler = (PWM_LED_TIM_GET_COUNTER_CLK_FREQ()/1000000) -1;
  PwmLed_TimerHandle.Init.Period = (PWM_LED_TIM_COUNTER_FREQ/PWM_LED_TIM_FREQ) - 1;
  if (HAL_TIM_Base_Init(&PwmLed_TimerHandle) != HAL_OK)
  {
    ret = BSP_ERROR_NO_INIT;
  }

  return ret;
}

/**
  * @brief  DeInitialize PWM LED Driver.
  * @retval BSP error code
  */
int32_t PWM_LED_DeInit(void)
{
  int32_t ret = BSP_ERROR_NONE;

  HAL_GPIO_DeInit(PWM_LED_SELECT_GPIO_PORT, PWM_LED_SELECT_GPIO_PIN);
  HAL_GPIO_DeInit(PWM_LED_SDI_GPIO_PORT, PWM_LED_SDI_GPIO_PIN);
  __HAL_TIM_DISABLE_IT(&PwmLed_TimerHandle, TIM_IT_UPDATE);
  if (HAL_TIM_PWM_DeInit(&PwmLed_TimerHandle) != HAL_OK)
  {
    ret = BSP_ERROR_UNKNOWN_FAILURE;
  }

  /* TIM17 MSP de-initialization */
  TIM17_MspDeInit(&PwmLed_TimerHandle);
  return ret;
}

/**
  * @brief  Set the GS data (PWM Control) for each output.
  * @param  aPwmLedGsData GS Data array (one element per output)
  * @retval BSP error code
  */
int32_t PWM_LED_On(aPwmLedGsData_TypeDef aPwmLedGsData)
{
  return PWM_LED_WriteData(aPwmLedGsData);
}

/**
  * @brief  Turn each output Off.
  * @retval BSP error code
  */
int32_t PWM_LED_Off(void)
{
  aPwmLedGsData_TypeDef aPwmLedGsData = {PWM_LED_GSDATA_OFF, PWM_LED_GSDATA_OFF, PWM_LED_GSDATA_OFF};
  return PWM_LED_WriteData(aPwmLedGsData);
}

/**
  * @brief  Toggle the selected LED.
  * @param  aPwmLedGsData GS (Gray Scale) data
  * @retval BSP error code
  */
int32_t PWM_LED_Toggle(aPwmLedGsData_TypeDef aPwmLedGsData)
{
  if (PWM_LED_GetState() == 0U)
  {
    return PWM_LED_WriteData(aPwmLedGsData);
  }
  else
  {
    return PWM_LED_Off();
  }
}

/**
  * @brief  Indicate whether outputs are turned on or off.
  * @retval 0 means off, 1 means on
  */
int32_t PWM_LED_GetState(void)
{
  return (((PWM_LED_GSDATA[PWM_LED_RED] == PWM_LED_GSDATA_OFF)
        && (PWM_LED_GSDATA[PWM_LED_GREEN] == PWM_LED_GSDATA_OFF)
        && (PWM_LED_GSDATA[PWM_LED_BLUE] == PWM_LED_GSDATA_OFF)) ? 0U : 1U);
}

/**
  * @brief  BSP PWM LED interrupt handler.
  * @retval None
  */
void PWM_LED_IRQHandler(void)
{
  __HAL_TIM_CLEAR_FLAG(&PwmLed_TimerHandle, TIM_IT_UPDATE);
  CycleCount++;
}


/**
  * @brief  Write GS data into the PWM LED driver through a single-wire interface
  * @param  aPwmLedGsData GS (Gray Scale) data
  * @retval BSP status
  */
static int32_t PWM_LED_WriteData(aPwmLedGsData_TypeDef aPwmLedGsData)
{
  if (aPwmLedGsData == NULL)
  {
    return BSP_ERROR_WRONG_PARAM;
  }

  __HAL_TIM_ENABLE_IT(&PwmLed_TimerHandle, TIM_IT_UPDATE);

  /* Start time base */
  if (HAL_TIM_Base_Start(&PwmLed_TimerHandle) != HAL_OK)
  {
    return BSP_ERROR_UNKNOWN_FAILURE;
  }

  /* Enable Grayscale (GS) Control */
  HAL_GPIO_WritePin(PWM_LED_SELECT_GPIO_PORT, PWM_LED_SELECT_GPIO_PIN, GPIO_PIN_RESET);
  HAL_Delay(10);
  HAL_GPIO_WritePin(PWM_LED_SELECT_GPIO_PORT, PWM_LED_SELECT_GPIO_PIN, GPIO_PIN_SET);

  /* TCycle measurement sequence */
  HAL_GPIO_WritePin(PWM_LED_SDI_GPIO_PORT, PWM_LED_SDI_GPIO_PIN, GPIO_PIN_RESET);
  PWM_LED_Wait(DELAY);
  HAL_GPIO_WritePin(PWM_LED_SDI_GPIO_PORT, PWM_LED_SDI_GPIO_PIN, GPIO_PIN_SET);
  PWM_LED_Wait(T_CYCLE_0);
  HAL_GPIO_WritePin(PWM_LED_SDI_GPIO_PORT, PWM_LED_SDI_GPIO_PIN, GPIO_PIN_RESET);
  PWM_LED_Wait(DELAY);
  HAL_GPIO_WritePin(PWM_LED_SDI_GPIO_PORT, PWM_LED_SDI_GPIO_PIN, GPIO_PIN_SET);
  PWM_LED_Wait(T_CYCLE_0);

  /* Write command */
  PWM_LED_SenByte(WRITE_COMMAND);

  /* Write the GS data */
  for (uint8_t gsdata = 0; gsdata < PWM_LED_NB; gsdata++)
  {
    PWM_LED_GSDATA[gsdata] = aPwmLedGsData[gsdata];
    PWM_LED_SenByte(PWM_LED_GSDATA[gsdata]);
  }

  /* Disable Grayscale (GS) Control */
  HAL_GPIO_WritePin(PWM_LED_SELECT_GPIO_PORT, PWM_LED_SELECT_GPIO_PIN, GPIO_PIN_RESET);

  /* Stop time base */
  if (HAL_TIM_Base_Stop(&PwmLed_TimerHandle) != HAL_OK)
  {
    return BSP_ERROR_UNKNOWN_FAILURE;
  }

  return BSP_ERROR_NONE;
}

/**
  * @brief  Data 0/1 write sequence
  * @param  bit
  * @retval None
  */
static void PWM_LED_SendBit(uint8_t bit)
{
  /* Start next cycle */
  HAL_GPIO_WritePin(PWM_LED_SDI_GPIO_PORT, PWM_LED_SDI_GPIO_PIN, GPIO_PIN_SET);
  PWM_LED_Wait(DELAY);
  HAL_GPIO_WritePin(PWM_LED_SDI_GPIO_PORT, PWM_LED_SDI_GPIO_PIN, GPIO_PIN_RESET);
  PWM_LED_Wait(DELAY);

  if (bit)
  {
    HAL_GPIO_WritePin(PWM_LED_SDI_GPIO_PORT, PWM_LED_SDI_GPIO_PIN, GPIO_PIN_SET);
    PWM_LED_Wait(DELAY);
    HAL_GPIO_WritePin(PWM_LED_SDI_GPIO_PORT, PWM_LED_SDI_GPIO_PIN, GPIO_PIN_RESET);
    PWM_LED_Wait(T_CYCLE_1);
  }
  else
  {
    PWM_LED_Wait(T_CYCLE_0);
  }
}

/**
  * @brief  Byte write Sequence
  * @param  byte
  * @retval None
  */
static void PWM_LED_SenByte(uint8_t byte)
{
    PWM_LED_SendBit(byte & (1<<7));
    PWM_LED_SendBit(byte & (1<<6));
    PWM_LED_SendBit(byte & (1<<5));
    PWM_LED_SendBit(byte & (1<<4));
    PWM_LED_SendBit(byte & (1<<3));
    PWM_LED_SendBit(byte & (1<<2));
    PWM_LED_SendBit(byte & (1<<1));
    PWM_LED_SendBit(byte & (1<<0));
}

/**
  * @brief  Byte write Sequence
  * @param  NbCycles Number of cycles to wait for
  * @retval None
  */
static void PWM_LED_Wait(uint32_t NbCycles)
{
  uint32_t start = CycleCount;

  while ((CycleCount - start) < NbCycles)
  {
  }
}

/**
  * @brief  Timer MSP initialization
  * @param  htim Timer instance
  * @retval None
  */
void TIM17_MspInit(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == PWM_LED_TIM)
  {
    PWM_LED_TIM_CLOCK_ENABLE();

    HAL_NVIC_SetPriority(PWM_LED_TIM_UP_IRQN, PWM_LED_CLOCK_IT_PRIORITY, 0);
    HAL_NVIC_EnableIRQ(PWM_LED_TIM_UP_IRQN);
  }
}

/**
  * @brief  Timer MSP de-initialization
  * @param  htim Timer instance
  * @retval None
  */
void TIM17_MspDeInit(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == PWM_LED_TIM)
  {
    HAL_NVIC_DisableIRQ(PWM_LED_TIM_UP_IRQN);
    PWM_LED_TIM_CLOCK_DISABLE();
  }
}
