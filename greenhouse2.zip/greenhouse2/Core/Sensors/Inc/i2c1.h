/*
 * i2c1.h
 *
 *  Created on: Oct 10, 2024
 *      Author: mag
 */

#ifndef SENSORS_INC_I2C1_H_
#define SENSORS_INC_I2C1_H_
#include "stm32wbxx_hal.h"
#include "sensors.h"
#define BUS_I2C1_TIMEOUT                10000U
extern I2C_HandleTypeDef hi2c1;


int32_t BSP_I2C1_WriteReg(uint16_t DevAddr, uint16_t Reg, uint8_t *pData, uint16_t Length);
int32_t BSP_I2C1_ReadReg(uint16_t DevAddr, uint16_t Reg, uint8_t *pData, uint16_t Length);
int32_t BSP_I2C1_Read(uint16_t DevAddr, uint8_t *pData, uint16_t Length);
int32_t BSP_I2C1_WriteReg16(uint16_t DevAddr, uint16_t Reg, uint8_t *pData, uint16_t Length);
int32_t BSP_I2C1_ReadReg16(uint16_t DevAddr, uint16_t Reg, uint8_t *pData, uint16_t Length);
int32_t BSP_I2C1_IsReady(uint16_t DevAddr, uint32_t Trials);


#endif /* SENSORS_INC_I2C1_H_ */
