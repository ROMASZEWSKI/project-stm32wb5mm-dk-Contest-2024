/*
 * pwmled.h
 *
 *  Created on: Oct 10, 2024
 *      Author: mag
 */

#ifndef SENSORS_INC_PWMLED_H_
#define SENSORS_INC_PWMLED_H_
#include "stm32wbxx_hal.h"
#include "stm32wbxx_hal_tim.h"
#include "sensors.h"



#define DELAY                       1u
#define T_CYCLE_0                   4u
#define T_CYCLE_1                   1u
#define WRITE_COMMAND               0x3Au
#define PWM_LED_CLOCK_IT_PRIORITY            0x03UL

/** @defgroup STM32WB5MM_DK_PWM_LED PWM LED
  * @{
  */
#define PWM_LEDn                                       1

#define PWM_LED_TIM                                    TIM17
#define PWM_LED_TIM_CLOCK_ENABLE()                     __HAL_RCC_TIM17_CLK_ENABLE()
#define PWM_LED_TIM_CLOCK_DISABLE()                    __HAL_RCC_TIM17_CLK_DISABLE()
#define PWM_LED_TIM_COUNTER_FREQ                       1000000
#define PWM_LED_TIM_FREQ                               200000
#define PWM_LED_TIM_GET_COUNTER_CLK_FREQ()             HAL_RCC_GetPCLK2Freq()
#define PWM_LED_TIM_UP_IRQN                            TIM1_TRG_COM_TIM17_IRQn

#define PWM_LED_SDI_GPIO_PIN                           GPIO_PIN_7
#define PWM_LED_SDI_GPIO_PORT                          GPIOA
#define PWM_LED_SDI_GPIO_CLK_ENABLE()                  __HAL_RCC_GPIOA_CLK_ENABLE()
#define PWM_LED_SDI_GPIO_CLK_DISABLE()                 __HAL_RCC_GPIOA_CLK_DISABLE()

#define PWM_LED_SELECT_GPIO_PIN                           GPIO_PIN_1
#define PWM_LED_SELECT_GPIO_PORT                          GPIOH
#define PWM_LED_SELECT_GPIO_CLK_ENABLE()                  __HAL_RCC_GPIOH_CLK_ENABLE()
#define PWM_LED_SELECT_GPIO_CLK_DISABLE()                 __HAL_RCC_GPIOH_CLK_DISABLE()

/** @defgroup STM32WB5MM_DK_COMMON_Exported_Types STM32WB5MM-DK COMMON Exported Types
  * @{
  */
typedef enum
{
  PWM_LED_RED = 0,
  PWM_LED_GREEN,
  PWM_LED_BLUE,
  PWM_LED_NB
} PwmLed_TypeDef;

typedef uint8_t PwmLedGsData_TypeDef;

typedef PwmLedGsData_TypeDef aPwmLedGsData_TypeDef[PWM_LED_NB];

#define PWM_LED_GSDATA_OFF    (PwmLedGsData_TypeDef) 0u     /* 0% On-Time duty cycle    */
#define PWM_LED_GSDATA_0_02   (PwmLedGsData_TypeDef) 1u     /* 0.02% On-Time duty cycle */
#define PWM_LED_GSDATA_0_05   (PwmLedGsData_TypeDef) 2u     /* 0.05% On-Time duty cycle */
#define PWM_LED_GSDATA_0_3    (PwmLedGsData_TypeDef) 3u     /* 0.3% On-Time duty cycle  */
#define PWM_LED_GSDATA_0_6    (PwmLedGsData_TypeDef) 6u     /* 0.6% On-Time duty cycle  */
#define PWM_LED_GSDATA_0_7    (PwmLedGsData_TypeDef) 7u     /* 0.7% On-Time duty cycle  */
#define PWM_LED_GSDATA_0_9    (PwmLedGsData_TypeDef) 8u     /* 0.9% On-Time duty cycle  */
#define PWM_LED_GSDATA_1_1    (PwmLedGsData_TypeDef) 9u     /* 1.1% On-Time duty cycle  */
#define PWM_LED_GSDATA_1_3    (PwmLedGsData_TypeDef) 10u    /* 1.3% On-Time duty cycle  */
#define PWM_LED_GSDATA_5_5    (PwmLedGsData_TypeDef) 30u    /* 5.5% On-Time duty cycle  */
#define PWM_LED_GSDATA_5_7    (PwmLedGsData_TypeDef) 31u    /* 5.7% On-Time duty cycle  */
#define PWM_LED_GSDATA_6_2    (PwmLedGsData_TypeDef) 32u    /* 6.2% On-Time duty cycle  */
#define PWM_LED_GSDATA_6_6    (PwmLedGsData_TypeDef) 33u    /* 6.6% On-Time duty cycle  */
#define PWM_LED_GSDATA_7_0    (PwmLedGsData_TypeDef) 34u    /* 7.0% On-Time duty cycle  */
#define PWM_LED_GSDATA_18_8   (PwmLedGsData_TypeDef) 62u    /* 18.8% On-Time duty cycle */
#define PWM_LED_GSDATA_19_2   (PwmLedGsData_TypeDef) 63u    /* 19.2% On-Time duty cycle */
#define PWM_LED_GSDATA_19_6   (PwmLedGsData_TypeDef) 64u    /* 19.6% On-Time duty cycle */
#define PWM_LED_GSDATA_20_0   (PwmLedGsData_TypeDef) 65u    /* 20.0% On-Time duty cycle */
#define PWM_LED_GSDATA_20_5   (PwmLedGsData_TypeDef) 66u    /* 20.5% On-Time duty cycle */
#define PWM_LED_GSDATA_46_1   (PwmLedGsData_TypeDef) 127u   /* 46.1% On-Time duty cycle */
#define PWM_LED_GSDATA_46_5   (PwmLedGsData_TypeDef) 128u   /* 46.5% On-Time duty cycle */
#define PWM_LED_GSDATA_47_0   (PwmLedGsData_TypeDef) 129u   /* 47% On-Time duty cycle   */
#define PWM_LED_GSDATA_99_1   (PwmLedGsData_TypeDef) 253u   /* 99.1% On-Time duty cycle */
#define PWM_LED_GSDATA_99_5   (PwmLedGsData_TypeDef) 254u   /* 99.5% On-Time duty cycle */
#define PWM_LED_GSDATA_99_9   (PwmLedGsData_TypeDef) 255u   /* 99.9% On-Time duty cycle */




int32_t PWM_LED_Init(void);
int32_t PWM_LED_DeInit(void);
int32_t PWM_LED_On(aPwmLedGsData_TypeDef aPwmLedGsData);
int32_t PWM_LED_Off(void);
int32_t PWM_LED_Toggle(aPwmLedGsData_TypeDef aPwmLedGsData);
int32_t PWM_LED_GetState(void);
void    PWM_LED_IRQHandler(void);

#endif /* SENSORS_INC_PWMLED_H_ */
