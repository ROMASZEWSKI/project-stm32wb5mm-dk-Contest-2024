/*
 * i2c3.h
 *
 *  Created on: Oct 10, 2024
 *      Author: mag
 */

#ifndef SENSORS_INC_I2C3_H_
#define SENSORS_INC_I2C3_H_
#include "stm32wbxx_hal.h"
#include "sensors.h"
#define BUS_I2C3_TIMEOUT                10000U
extern I2C_HandleTypeDef hi2c3;


int32_t BSP_I2C3_WriteReg(uint16_t DevAddr, uint16_t Reg, uint8_t *pData, uint16_t Length);
int32_t BSP_I2C3_ReadReg(uint16_t DevAddr, uint16_t Reg, uint8_t *pData, uint16_t Length);
int32_t BSP_I2C3_Read(uint16_t DevAddr, uint8_t *pData, uint16_t Length);
int32_t BSP_I2C3_WriteReg16(uint16_t DevAddr, uint16_t Reg, uint8_t *pData, uint16_t Length);
int32_t BSP_I2C3_ReadReg16(uint16_t DevAddr, uint16_t Reg, uint8_t *pData, uint16_t Length);
int32_t BSP_I2C3_IsReady(uint16_t DevAddr, uint32_t Trials);


#endif /* SENSORS_INC_I2C3_H_ */
