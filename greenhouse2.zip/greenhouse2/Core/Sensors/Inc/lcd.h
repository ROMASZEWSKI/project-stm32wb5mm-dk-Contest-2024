/**
  ******************************************************************************
  * @file    lcd.h
  * @author  MCD Application Team
  * @brief   This file contains all the functions prototypes for the LCD driver.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2018 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef LCD_H
#define LCD_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
#include "stm32wbxx_hal.h"
#include "spi1.h"
#include "ssd1315.h"
#include "fonts.h"

/* Include audio component Driver */
#ifndef USE_LCD_CTRL_SSD1315
#define USE_LCD_CTRL_SSD1315          1U
#endif

#define LCD_PIXEL_FORMAT_ARGB8888        0x00000000U   /*!< ARGB8888 LTDC pixel format */
#define LCD_PIXEL_FORMAT_RGB888          0x00000001U   /*!< RGB888 LTDC pixel format   */
#define LCD_PIXEL_FORMAT_RGB565          0x00000002U   /*!< RGB565 LTDC pixel format   */
#define LCD_PIXEL_FORMAT_ARGB1555        0x00000003U   /*!< ARGB1555 LTDC pixel format */
#define LCD_PIXEL_FORMAT_ARGB4444        0x00000004U   /*!< ARGB4444 LTDC pixel format */
#define LCD_PIXEL_FORMAT_L8              0x00000005U   /*!< L8 LTDC pixel format       */
#define LCD_PIXEL_FORMAT_AL44            0x00000006U   /*!< AL44 LTDC pixel format     */
#define LCD_PIXEL_FORMAT_AL88            0x00000007U   /*!< AL88 LTDC pixel format     */

typedef struct
{
  int32_t (*DrawBitmap)(uint32_t, uint32_t, uint32_t, uint8_t *);
  int32_t (*FillRGBRect)(uint32_t, uint32_t, uint32_t, uint8_t *, uint32_t, uint32_t);
  int32_t (*DrawHLine)(uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);
  int32_t (*DrawVLine)(uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);
  int32_t (*FillRect)(uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);
  int32_t (*GetPixel)(uint32_t, uint32_t, uint32_t, uint32_t *);
  int32_t (*SetPixel)(uint32_t, uint32_t, uint32_t, uint32_t);
  int32_t (*GetXSize)(uint32_t, uint32_t *);
  int32_t (*GetYSize)(uint32_t, uint32_t *);
  int32_t (*SetLayer)(uint32_t, uint32_t);
  int32_t (*GetFormat)(uint32_t, uint32_t *);
} LCD_UTILS_Drv_t;

typedef struct
{
  /* Control functions */
  int32_t (*Init)(void *, uint32_t, uint32_t);
  int32_t (*DeInit)(void *);
  int32_t (*ReadID)(void *, uint32_t *);
  int32_t (*DisplayOn)(void *);
  int32_t (*DisplayOff)(void *);
  int32_t (*SetBrightness)(void *, uint32_t);
  int32_t (*GetBrightness)(void *, uint32_t *);
  int32_t (*SetOrientation)(void *, uint32_t);
  int32_t (*GetOrientation)(void *, uint32_t *);

  /* Drawing functions*/
  int32_t (*SetCursor)(void *, uint32_t, uint32_t);
  int32_t (*DrawBitmap)(void *, uint32_t, uint32_t, uint8_t *);
  int32_t (*FillRGBRect)(void *, uint32_t, uint32_t, uint8_t *, uint32_t, uint32_t);
  int32_t (*DrawHLine)(void *, uint32_t, uint32_t, uint32_t, uint32_t);
  int32_t (*DrawVLine)(void *, uint32_t, uint32_t, uint32_t, uint32_t);
  int32_t (*FillRect)(void *, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);
  int32_t (*GetPixel)(void *, uint32_t, uint32_t, uint32_t *);
  int32_t (*SetPixel)(void *, uint32_t, uint32_t, uint32_t);
  int32_t (*GetXSize)(void *, uint32_t *);
  int32_t (*GetYSize)(void *, uint32_t *);
} LCD_Drv_t;




#define LCD_INSTANCES_NBR                1U
#define LCD_ORIENTATION_LANDSCAPE        SSD1315_ORIENTATION_LANDSCAPE
#define LCD_DEFAULT_WIDTH                SSD1315_LCD_PIXEL_WIDTH
#define LCD_DEFAULT_HEIGHT               SSD1315_LCD_PIXEL_HEIGHT
#define LCD_COLOR_BLACK                  SSD1315_COLOR_BLACK
#define LCD_COLOR_WHITE                  SSD1315_COLOR_WHITE

/*##################### LCD ###################################*/
/**
  * @brief  LCD Chip Select macro definition
  */
 #define LCD_CS_LOW()                    HAL_GPIO_WritePin(LCD_CS_GPIO_PORT, LCD_CS_PIN, GPIO_PIN_RESET)
 #define LCD_CS_HIGH()                   HAL_GPIO_WritePin(LCD_CS_GPIO_PORT, LCD_CS_PIN, GPIO_PIN_SET)

/**
  * @brief  LCD Control pins
  */
#define LCD_CS_PIN                      GPIO_PIN_0		/* PH. 0*/
#define LCD_CS_GPIO_PORT                GPIOH			/* GPIOH */
#define LCD_CS_GPIO_CLK_ENABLE()        __HAL_RCC_GPIOH_CLK_ENABLE()
#define LCD_CS_GPIO_CLK_DISABLE()       __HAL_RCC_GPIOH_CLK_DISABLE()

/**
  * @brief  LCD Reset macro definition
  */
#define LCD_RST_LOW()                    HAL_GPIO_WritePin(LCD_RST_GPIO_PORT, LCD_RST_PIN, GPIO_PIN_RESET)
#define LCD_RST_HIGH()                   HAL_GPIO_WritePin(LCD_RST_GPIO_PORT, LCD_RST_PIN, GPIO_PIN_SET)

/**
  * @brief  LCD Reset pins
  */
#define LCD_RST_PIN                     GPIO_PIN_8		/* PC. 08*/
#define LCD_RST_GPIO_PORT               GPIOC			/* GPIOC */
#define LCD_RST_GPIO_CLK_ENABLE()       __HAL_RCC_GPIOC_CLK_ENABLE()
#define LCD_RST_GPIO_CLK_DISABLE()      __HAL_RCC_GPIOC_CLK_DISABLE()

/**
  * @brief  LCD Data/Command macro definition
  */
#define LCD_DC_LOW()                    HAL_GPIO_WritePin(LCD_DC_GPIO_PORT, LCD_DC_PIN, GPIO_PIN_RESET)
#define LCD_DC_HIGH()                   HAL_GPIO_WritePin(LCD_DC_GPIO_PORT, LCD_DC_PIN, GPIO_PIN_SET)

/**
  * @brief
  */
#define LCD_DC_PIN                      GPIO_PIN_9		/* PC. 09*/
#define LCD_DC_GPIO_PORT                GPIOC    		/* GPIOC */
#define LCD_DC_GPIO_CLK_ENABLE()        __HAL_RCC_GPIOC_CLK_ENABLE()
#define LCD_DC_GPIO_CLK_DISABLE()       __HAL_RCC_GPIOC_CLK_DISABLE()

/**
  * @}
  */

/** @defgroup STM32WB5MM_DK_LCD_Exported_Types Exported Types
  * @{
  */
typedef struct
{
  uint32_t Width;
  uint32_t Height;
  uint32_t IsMspCallbacksValid;
}BSP_LCD_Ctx_t;

/**
  * @}
  */

/** @addtogroup STM32WB5MM_DK_LCD_Private_Variables
  * @{
  */
extern void                 *LcdCompObj;
extern BSP_LCD_Ctx_t        LcdCtx[];
extern const LCD_UTILS_Drv_t LCD_Driver;
/**
  * @}
  */

/** @defgroup STM32WB5MM_DK_LCD_Exported_Functions Exported Functions
  * @{
  */
int32_t  BSP_LCD_Init(uint32_t Instance, uint32_t Orientation);
int32_t  BSP_LCD_DeInit(uint32_t Instance);

/* LCD generic APIs: Display control */
int32_t  BSP_LCD_DisplayOn(uint32_t Instance);
int32_t  BSP_LCD_DisplayOff(uint32_t Instance);
int32_t  BSP_LCD_SetBrightness(uint32_t Instance, uint32_t Brightness);
int32_t  BSP_LCD_GetBrightness(uint32_t Instance, uint32_t *Brightness);
int32_t  BSP_LCD_GetXSize(uint32_t Instance, uint32_t *XSize);
int32_t  BSP_LCD_GetYSize(uint32_t Instance, uint32_t *YSize);
int32_t  BSP_LCD_GetPixelFormat(uint32_t Instance, uint32_t *PixelFormat);
int32_t  BSP_LCD_SetOrientation(uint32_t Instance, uint32_t Orientation);
int32_t  BSP_LCD_GetOrientation(uint32_t Instance, uint32_t *Orientation);
int32_t  BSP_LCD_Refresh(uint32_t Instance);
int32_t  BSP_LCD_SetPage(uint32_t Instance, uint16_t Page);
int32_t  BSP_LCD_SetColumn(uint32_t Instance, uint16_t Column);
int32_t  BSP_LCD_ScrollingSetup(uint32_t Instance, uint16_t ScrollMode, uint16_t StartPage, uint16_t EndPage, uint16_t Frequency);
int32_t  BSP_LCD_ScrollingStart(uint32_t Instance);
int32_t  BSP_LCD_ScrollingStop(uint32_t Instance);
int32_t  BSP_LCD_SetCursor(uint32_t Instance, uint32_t Xpos, uint32_t Ypos);
int32_t  BSP_LCD_DrawBitmap(uint32_t Instance, uint32_t Xpos, uint32_t Ypos, uint8_t *pBmp);
int32_t  BSP_LCD_ShiftBitmap(uint32_t Instance, uint32_t Xpos, uint32_t Ypos, int16_t Xshift, int16_t Yshift, uint8_t *pBmp);
int32_t  BSP_LCD_DrawHLine(uint32_t Instance, uint32_t Xpos, uint32_t Ypos, uint32_t Length, uint32_t Color);
int32_t  BSP_LCD_DrawVLine(uint32_t Instance, uint32_t Xpos, uint32_t Ypos, uint32_t Length, uint32_t Color);
int32_t  BSP_LCD_FillRect(uint32_t Instance, uint32_t Xpos, uint32_t Ypos, uint32_t Width, uint32_t Height, uint32_t Color);
int32_t  BSP_LCD_FillRGBRect(uint32_t Instance, uint32_t Xpos, uint32_t Ypos, uint8_t *pData, uint32_t Width, uint32_t Height);
int32_t  BSP_LCD_ReadPixel(uint32_t Instance, uint32_t Xpos, uint32_t Ypos, uint32_t *Color);
int32_t  BSP_LCD_WritePixel(uint32_t Instance, uint32_t Xpos, uint32_t Ypos, uint32_t Color);
int32_t  BSP_LCD_Clear(uint32_t Instance, uint32_t Color);
int32_t  BSP_LCD_SetActiveLayer(uint32_t Instance, uint32_t LayerIndex);
int32_t  BSP_LCD_SetPixel(uint32_t Instance, uint32_t Xpos, uint32_t Ypos, uint32_t Color);
int32_t  BSP_LCD_GetPixel(uint32_t Instance, uint32_t Xpos, uint32_t Ypos, uint32_t *Color);

/* LCD specific APIs */
int32_t  BSP_LCD_WriteReg(uint16_t Reg, uint8_t *pData, uint16_t Length);
int32_t  BSP_LCD_ReadReg(uint16_t Reg, uint8_t *pData, uint16_t Length);
int32_t  BSP_LCD_SendData(uint8_t *pData, uint16_t Length);


#ifdef __cplusplus
}
#endif

#endif /* LCD_H */
