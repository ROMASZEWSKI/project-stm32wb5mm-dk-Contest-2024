/*
 * spi1.h
 *
 *  Created on: Oct 10, 2024
 *      Author: mag
 */

#ifndef SENSORS_INC_SPI1_H_
#define SENSORS_INC_SPI1_H_

#include "stm32wbxx_hal.h"
#include "sensors.h"

#define BUS_SPI1_TIMEOUT                  ((uint32_t)0x1000)
// BUS_SPI1_SCK_PIN                  GPIO_PIN_1                 /* PA.01*/
// BUS_SPI1_MOSI_PIN                 GPIO_PIN_7                 /* PA.07 */
extern SPI_HandleTypeDef hspi1;
int32_t BSP_SPI1_Send(uint8_t *pData, uint16_t Length);
int32_t  BSP_SPI1_Recv(uint8_t *pData, uint16_t Length);
int32_t BSP_GetTick(void);


#endif /* SENSORS_INC_SPI1_H_ */
