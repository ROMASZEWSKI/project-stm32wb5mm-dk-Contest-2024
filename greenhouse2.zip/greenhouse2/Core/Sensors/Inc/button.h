/*
 * button.h
 *
 *  Created on: Oct 10, 2024
 *      Author: mag
 */

#ifndef SENSORS_INC_BUTTON_H_
#define SENSORS_INC_BUTTON_H_

#include "stm32wbxx_hal.h"
#include "sensors.h"

typedef enum
{
  BUTTON_USER1 = 0,
  BUTTON_USER2
} Button_TypeDef;

typedef enum
{
  BUTTON_MODE_GPIO = 0,
  BUTTON_MODE_EXTI = 1
} ButtonMode_TypeDef;

typedef void (* BSP_EXTI_LineCallback)(void);

/** @defgroup STM32WB5MM_DK_BUTTON BUTTON
  * @{
  */
#define BUTTONn                                 2
#define BSP_BUTTON_USERx_IT_PRIORITY         0x0FUL

/**
 * @brief Key push-buttons
 */
#define BUTTON_USER1_PIN                          GPIO_PIN_12
#define BUTTON_USER1_GPIO_PORT                    GPIOC
#define BUTTON_USER1_GPIO_CLK_ENABLE()            __HAL_RCC_GPIOC_CLK_ENABLE()
#define BUTTON_USER1_GPIO_CLK_DISABLE()           __HAL_RCC_GPIOC_CLK_DISABLE()
#define BUTTON_USER1_EXTI_LINE                    EXTI_LINE_12
#ifdef CORE_CM0PLUS
#define BUTTON_USER1_EXTI_IRQn                    EXTI15_4_IRQn
#else
#define BUTTON_USER1_EXTI_IRQn                    EXTI15_10_IRQn
#endif

#define BUTTON_USER2_PIN                          GPIO_PIN_13
#define BUTTON_USER2_GPIO_PORT                    GPIOC
#define BUTTON_USER2_GPIO_CLK_ENABLE()            __HAL_RCC_GPIOC_CLK_ENABLE()
#define BUTTON_USER2_GPIO_CLK_DISABLE()           __HAL_RCC_GPIOC_CLK_DISABLE()
#define BUTTON_USER2_EXTI_LINE                    EXTI_LINE_13
#ifdef CORE_CM0PLUS
#define BUTTON_USER2_EXTI_IRQn                    EXTI15_4_IRQn
#else
#define BUTTON_USER2_EXTI_IRQn                    EXTI15_10_IRQn
#endif /* CORE_CM0PLUS */

#define BUTTON_USERx_GPIO_CLK_ENABLE(__INDEX__)    do { if ((__INDEX__) == BUTTON_USER1) BUTTON_USER1_GPIO_CLK_ENABLE(); else \
                                                        if ((__INDEX__) == BUTTON_USER2) BUTTON_USER2_GPIO_CLK_ENABLE();} while(0)

#define BUTTON_USERx_GPIO_CLK_DISABLE(__INDEX__)    do { if ((__INDEX__) == BUTTON_USER1) BUTTON_USER1_GPIO_CLK_DISABLE(); else \
                                                         if ((__INDEX__) == BUTTON_USER2) BUTTON_USER2_GPIO_CLK_DISABLE();} while(0)


int32_t BSP_PB_Init(Button_TypeDef Button, ButtonMode_TypeDef ButtonMode);
int32_t BSP_PB_DeInit(Button_TypeDef Button);
int32_t BSP_PB_GetState(Button_TypeDef Button);
void    BSP_PB_Callback(Button_TypeDef Button);
void    BSP_PB_IRQHandler(Button_TypeDef Button);

extern EXTI_HandleTypeDef hpb_exti[];

#endif /* SENSORS_INC_BUTTON_H_ */
