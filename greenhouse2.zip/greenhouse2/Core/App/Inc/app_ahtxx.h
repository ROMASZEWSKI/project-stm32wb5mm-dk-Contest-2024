/*
 * app_athxx.h
 *
 *  Created on: Jan 10, 2024
 *      Author: mag
 */

#ifndef APPLICATION_USER_CORE_APP_AHTXX_H_
#define APPLICATION_USER_CORE_APP_AHTXX_H_

#include "ahtxx.h"
void init_AHTxx(void);
void read_AHTxx(void);

#endif /* APPLICATION_USER_CORE_APP_AHTXX_H_ */
