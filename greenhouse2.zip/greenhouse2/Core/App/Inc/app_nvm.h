/*
 * app_nvm.h
 *
 *  Created on: Oct 10, 2024
 *      Author: mag
 */

#ifndef APP_INC_APP_NVM_H_
#define APP_INC_APP_NVM_H_
#include "app_common.h"
#include "app_conf.h"
#include "dbg_trace.h"
#include "stm_logging.h"
#include "zigbee.h"
#include "app_clusters.h"
#include "ee.h"
#include "hw_flash.h"


/* cache in uninit RAM to store/retrieve persistent data */
union cache
{
  uint8_t  U8_data[ST_PERSIST_MAX_ALLOC_SZ];     // in bytes
  uint32_t U32_data[ST_PERSIST_MAX_ALLOC_SZ/4U]; // in U32 words
};
extern union cache cache_persistent_data;
extern union cache cache_diag_reference;


#define CONFIG_NVM 1

extern struct zigbee_app_info zigbee_app_info;

void APP_ZIGBEE_persist_notify_cb(struct ZigBeeT *zb, void *cbarg);
enum ZbStatusCodeT APP_ZIGBEE_ZbStartupPersist(struct ZigBeeT* zb);
void APP_ZIGBEE_PersistCompleted_callback(enum ZbStatusCodeT status,void *arg);
bool APP_ZIGBEE_persist_load(void);
bool APP_ZIGBEE_persist_save(void);
void APP_ZIGBEE_persist_delete(void);
void APP_ZIGBEE_NVM_Init(void);

#endif /* APP_INC_APP_NVM_H_ */
