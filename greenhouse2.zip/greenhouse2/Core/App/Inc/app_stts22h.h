/*
 * app_stts22h.h
 *
 *  Created on: Oct 12, 2024
 *      Author: mag
 */

#ifndef APP_INC_APP_STTS22H_H_
#define APP_INC_APP_STTS22H_H_

#include "stts22h.h"
#include "spi1.h"

int32_t STTS22H_Init_Sensor(void);
void STTS22H_getTemperatureValue(float *value);

#endif /* APP_INC_APP_STTS22H_H_ */
